<?php
include '../conexao.php';

$erro = '';
$sucesso = '';


$visitas_query = "
    SELECT 
        v.idVISITA, 
        c.nome AS nome_cliente, 
        cr.nome AS nome_corretor
    FROM VISITA v
    INNER JOIN CLIENTE c ON v.CLIENTE_idCLIENTE = c.idCLIENTE
    INNER JOIN CORRETOR cr ON v.CORRETOR_idCORRETOR = cr.idCORRETOR
    ORDER BY v.idVISITA
";

$visitas_result = mysqli_query($conexao, $visitas_query);


$idVisita = '';
$valor_ofertado = '';
$data_proposta = '';
$status = 'pendente';  

if ($_POST) {
    $idVisita = (int)$_POST['VISITA_idVISITA'];
    $valor_ofertado = $_POST['valor_ofertado'];
    $data_proposta = $_POST['data_proposta'];
    $status = $_POST['status'];

   
    if ($idVisita <= 0) {
        $erro = "Selecione uma visita válida.";
    } elseif (!in_array($status, ['pendente', 'aceita', 'recusada'])) {
        $erro = "Status inválido.";
    } elseif (!preg_match('/^\d+(\.\d{1,2})?$/', $valor_ofertado)) {
        $erro = "Valor ofertado inválido. Use formato decimal (ex: 1500.00).";
    } else {
       
        $queryCliente = "SELECT CLIENTE_idCLIENTE FROM VISITA WHERE idVISITA = $idVisita";
        $resCliente = mysqli_query($conexao, $queryCliente);
        if (mysqli_num_rows($resCliente) == 0) {
            $erro = "Visita selecionada não encontrada.";
        } else {
            $rowCliente = mysqli_fetch_assoc($resCliente);
            $clienteId = $rowCliente['CLIENTE_idCLIENTE'];

            
            $sql = "INSERT INTO PROPOSTA (VISITA_idVISITA, VISITA_CLIENTE_idCLIENTE, valor_ofertado, data_proposta, status) 
                    VALUES ($idVisita, $clienteId, '$valor_ofertado', " . 
                    ($data_proposta ? "'$data_proposta'" : "NULL") . ", '$status')";

            if (mysqli_query($conexao, $sql)) {
                $sucesso = "Proposta cadastrada com sucesso! <a href='listar.php'>Ver todas</a>";
                
                $idVisita = '';
                $valor_ofertado = '';
                $data_proposta = '';
                $status = 'pendente';
            } else {
                $erro = "Erro ao cadastrar proposta: " . mysqli_error($conexao);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Proposta</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 480px;
        }
        label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }
        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }
        input:focus,
        select:focus {
            border-color: #3b82f6;
            outline: none;
        }
        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }
        input[type="submit"],
        input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }
        input[type="submit"]:hover,
        input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }
        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .sucesso {
            color: green;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <h2>Cadastrar Proposta</h2>

    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php elseif ($sucesso): ?>
        <div class="sucesso"><?= $sucesso ?></div>
    <?php endif; ?>

    <label for="visita">Visita (Cliente / Corretor):
        <select name="VISITA_idVISITA" id="visita" required>
            <option value="">-- Selecione uma visita --</option>
            <?php while ($visita = mysqli_fetch_assoc($visitas_result)): ?>
                <option value="<?= $visita['idVISITA'] ?>" <?= ($visita['idVISITA'] == $idVisita) ? 'selected' : '' ?>>
                    <?= $visita['idVISITA'] ?> - Cliente: <?= htmlspecialchars($visita['nome_cliente']) ?> / Corretor: <?= htmlspecialchars($visita['nome_corretor']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </label>

    <label for="valor_ofertado">Valor Ofertado (ex: 1500.00):
        <input type="text" name="valor_ofertado" id="valor_ofertado" value="<?= htmlspecialchars($valor_ofertado) ?>" required pattern="\d+(\.\d{1,2})?" title="Número decimal, ex: 1500.00">
    </label>

    <label for="data_proposta">Data da Proposta:
        <input type="date" name="data_proposta" id="data_proposta" value="<?= htmlspecialchars($data_proposta) ?>">
    </label>

    <label for="status">Status:
        <select name="status" id="status" required>
            <option value="pendente" <?= $status == 'pendente' ? 'selected' : '' ?>>Pendente</option>
            <option value="aceita" <?= $status == 'aceita' ? 'selected' : '' ?>>Aceita</option>
            <option value="recusada" <?= $status == 'recusada' ? 'selected' : '' ?>>Recusada</option>
        </select>
    </label>

    <div class="button-group">
        <input type="submit" value="Cadastrar">
        <input type="button" value="Voltar" onclick="window.location.href='listar.php'">
    </div>
</form>

</body>
</html>
