<?php
include '../conexao.php';

$erro = '';
$sucesso = '';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    
    $query = "
        SELECT 
            p.*, 
            c.nome AS nome_cliente, 
            cr.nome AS nome_corretor
        FROM PROPOSTA p
        INNER JOIN VISITA v ON p.VISITA_idVISITA = v.idVISITA AND p.VISITA_CLIENTE_idCLIENTE = v.CLIENTE_idCLIENTE
        INNER JOIN CLIENTE c ON v.CLIENTE_idCLIENTE = c.idCLIENTE
        INNER JOIN CORRETOR cr ON v.CORRETOR_idCORRETOR = cr.idCORRETOR
        WHERE p.idPROPOSTA = $id
    ";

    $resultado = mysqli_query($conexao, $query);
    $proposta = mysqli_fetch_assoc($resultado);

    if (!$proposta) {
        die("Proposta não encontrada.");
    }
} else {
    die("ID da proposta não informado.");
}

if ($_POST) {
    $id = (int)$_POST['id'];

    
    $sql = "DELETE FROM PROPOSTA WHERE idPROPOSTA = $id";
    if (mysqli_query($conexao, $sql)) {
        $sucesso = "Proposta excluída com sucesso! <a href='listar.php'>Voltar</a>";
    } else {
        $erro = "Erro ao excluir proposta: " . mysqli_error($conexao);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Excluir Proposta</title>
    <style>
        
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            text-align: center;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            padding: 12px 30px;
            font-size: 16px;
            background-color: #ef4444;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .button-group input[type="button"] {
            background-color: #6b7280;
        }

        .button-group input[type="submit"]:hover {
            background-color: #dc2626;
            transform: translateY(-2px);
        }

        .button-group input[type="button"]:hover {
            background-color: #4b5563;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .sucesso {
            color: green;
            margin-bottom: 15px;
            font-weight: bold;
        }

        p {
            font-size: 16px;
            margin: 8px 0;
        }
    </style>
</head>
<body>

<div class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php elseif ($sucesso): ?>
        <div class="sucesso"><?= $sucesso ?></div>
    <?php else: ?>
        <h2>Tem certeza que deseja excluir esta proposta?</h2>

        <p><strong>ID:</strong> <?= htmlspecialchars($proposta['idPROPOSTA']) ?></p>
        <p><strong>Cliente:</strong> <?= htmlspecialchars($proposta['nome_cliente']) ?></p>
        <p><strong>Corretor:</strong> <?= htmlspecialchars($proposta['nome_corretor']) ?></p>
        <p><strong>Valor Ofertado:</strong> R$ <?= htmlspecialchars(number_format($proposta['valor_ofertado'], 2, ',', '.')) ?></p>
        <p><strong>Status:</strong> <?= htmlspecialchars($proposta['status']) ?></p>
        <p><strong>Data da Proposta:</strong> <?= htmlspecialchars($proposta['data_proposta']) ?></p>

        <form method="post">
            <input type="hidden" name="id" value="<?= $proposta['idPROPOSTA'] ?>">
            <div class="button-group">
                <input type="submit" value="Sim, excluir">
                <input type="button" value="Cancelar" onclick="window.location.href='listar.php'">
            </div>
        </form>
    <?php endif; ?>
</div>

</body>
</html>

