<?php
include '../conexao.php';

$erro = '';
$sucesso = '';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $resultado = mysqli_query($conexao, "SELECT * FROM PROPOSTA WHERE idPROPOSTA = $id");
    $proposta = mysqli_fetch_assoc($resultado);

    if (!$proposta) {
        die("Proposta não encontrada.");
    }
}

if ($_POST) {
    $originalId = (int)$_POST['original_id'];
    $novoId = (int)$_POST['idPROPOSTA'];
    $idVisita = (int)$_POST['VISITA_idVISITA'];
    $clienteId = (int)$_POST['VISITA_CLIENTE_idCLIENTE'];
    $valorOfertado = $_POST['valor_ofertado'];
    $dataProposta = $_POST['data_proposta'];
    $status = $_POST['status'];

    
    $verifica = mysqli_query($conexao, "
        SELECT idPROPOSTA FROM PROPOSTA 
        WHERE idPROPOSTA = $novoId AND idPROPOSTA != $originalId
    ");
    if (mysqli_num_rows($verifica) > 0) {
        $erro = "Já existe outra proposta com este ID.";
    } else {
        
        $verificaVisita = mysqli_query($conexao, "
            SELECT * FROM VISITA 
            WHERE idVISITA = $idVisita AND CLIENTE_idCLIENTE = $clienteId
        ");
        if (mysqli_num_rows($verificaVisita) === 0) {
            $erro = "A VISITA informada não existe.";
        } else {
           
            $sql = "
                UPDATE PROPOSTA SET 
                    idPROPOSTA = $novoId,
                    VISITA_idVISITA = $idVisita,
                    VISITA_CLIENTE_idCLIENTE = $clienteId,
                    valor_ofertado = " . ($valorOfertado ? $valorOfertado : "NULL") . ",
                    data_proposta = " . ($dataProposta ? "'$dataProposta'" : "NULL") . ",
                    status = '$status'
                WHERE idPROPOSTA = $originalId
            ";

            if (mysqli_query($conexao, $sql)) {
                $sucesso = "Proposta atualizada com sucesso! <a href='listar.php'>Voltar</a>";
                $proposta = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM PROPOSTA WHERE idPROPOSTA = $novoId"));
            } else {
                $erro = "Erro ao atualizar proposta: " . mysqli_error($conexao);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Proposta</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 520px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="date"],
        .form-container select {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus,
        .form-container select:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #f59e0b;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #d97706;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .sucesso {
            color: green;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php elseif ($sucesso): ?>
        <div class="sucesso"><?= $sucesso ?></div>
    <?php endif; ?>

    <input type="hidden" name="original_id" value="<?= $proposta['idPROPOSTA'] ?>">

    <label>ID Proposta:
        <input type="number" name="idPROPOSTA" value="<?= htmlspecialchars($proposta['idPROPOSTA']) ?>" min="0" required>
    </label>
    <label>ID Visita:
        <input type="number" name="VISITA_idVISITA" value="<?= htmlspecialchars($proposta['VISITA_idVISITA']) ?>" min="0" required>
    </label>
    <label>ID Cliente da Visita:
        <input type="number" name="VISITA_CLIENTE_idCLIENTE" value="<?= htmlspecialchars($proposta['VISITA_CLIENTE_idCLIENTE']) ?>" min="0" required>
    </label>
    <label>Valor Ofertado:
        <input type="number" step="0.01" name="valor_ofertado" value="<?= htmlspecialchars($proposta['valor_ofertado']) ?>">
    </label>
    <label>Data da Proposta:
        <input type="date" name="data_proposta" value="<?= htmlspecialchars($proposta['data_proposta']) ?>">
    </label>
    <label>Status:
        <select name="status" required>
            <option value="pendente" <?= $proposta['status'] == 'pendente' ? 'selected' : '' ?>>Pendente</option>
            <option value="aceita" <?= $proposta['status'] == 'aceita' ? 'selected' : '' ?>>Aceita</option>
            <option value="recusada" <?= $proposta['status'] == 'recusada' ? 'selected' : '' ?>>Recusada</option>
        </select>
    </label>

    <div class="button-group">
        <input type="submit" value="Salvar Alterações">
        <input type="button" value="Voltar" onclick="window.location.href='listar.php'">
    </div>
</form>

</body>
</html>
