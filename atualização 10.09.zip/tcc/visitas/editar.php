<?php
include '../conexao.php';

$erro = '';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $resultado = mysqli_query($conexao, "SELECT * FROM VISITA WHERE idVISITA = $id");
    $visita = mysqli_fetch_assoc($resultado);
}

if ($_POST) {
    $originalId = (int)$_POST['original_id'];
    $novoId = (int)$_POST['idVISITA'];
    $corretor = (int)$_POST['CORRETOR_idCORRETOR'];
    $imovel = (int)$_POST['IMOVEL_idIMOVEL'];
    $cliente = (int)$_POST['CLIENTE_idCLIENTE'];
    $data_visita = mysqli_real_escape_string($conexao, $_POST['data_visita']);
    $observacoes = mysqli_real_escape_string($conexao, $_POST['observacoes']);

    if ($novoId < 0) {
        $erro = "O ID da visita não pode ser menor que 0.";
    } else {
        
        $verificaId = mysqli_query($conexao, "
            SELECT idVISITA 
            FROM VISITA 
            WHERE idVISITA = $novoId AND idVISITA != $originalId
        ");

        if (mysqli_num_rows($verificaId) > 0) {
            $erro = "O ID da visita informado já está em uso por outra visita.";
        } else {
            
            $verificaCorretor = mysqli_query($conexao, "
                SELECT idCORRETOR 
                FROM CORRETOR 
                WHERE idCORRETOR = $corretor
            ");

            if (mysqli_num_rows($verificaCorretor) == 0) {
                $erro = "O ID do corretor informado não existe.";
            } else {
                
                $verificaImovel = mysqli_query($conexao, "
                    SELECT idIMOVEL 
                    FROM IMOVEL 
                    WHERE idIMOVEL = $imovel
                ");

                if (mysqli_num_rows($verificaImovel) == 0) {
                    $erro = "O ID do imóvel informado não existe.";
                } else {
                    
                    $verificaCliente = mysqli_query($conexao, "
                        SELECT idCLIENTE 
                        FROM CLIENTE 
                        WHERE idCLIENTE = $cliente
                    ");

                    if (mysqli_num_rows($verificaCliente) == 0) {
                        $erro = "O ID do cliente informado não existe.";
                    } else {
                        
                        $sql = "UPDATE VISITA SET 
                                    idVISITA = '$novoId',
                                    CORRETOR_idCORRETOR = '$corretor',
                                    IMOVEL_idIMOVEL = '$imovel',
                                    CLIENTE_idCLIENTE = '$cliente',
                                    data_visita = '$data_visita',
                                    observacoes = '$observacoes'
                                WHERE idVISITA = '$originalId'";

                        if (mysqli_query($conexao, $sql)) {
                            echo "Visita atualizada com sucesso! <a href='listar.php'>Voltar</a>";
                        } else {
                            $erro = "Erro ao atualizar: " . mysqli_error($conexao);
                        }

                        exit;
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Visita</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 480px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="date"],
        .form-container textarea {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus,
        .form-container textarea:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: rgba(25, 26, 30, 1);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php endif; ?>

    <input type="hidden" name="original_id" value="<?= $visita['idVISITA'] ?>">

    <label>ID Visita:
        <input type="number" name="idVISITA" value="<?= htmlspecialchars($visita['idVISITA']) ?>" min="0" required>
    </label>
    <label>ID Corretor:
        <input type="number" name="CORRETOR_idCORRETOR" value="<?= htmlspecialchars($visita['CORRETOR_idCORRETOR']) ?>" required>
    </label>
    <label>ID Imóvel:
        <input type="number" name="IMOVEL_idIMOVEL" value="<?= htmlspecialchars($visita['IMOVEL_idIMOVEL']) ?>" required>
    </label>
    <label>ID Cliente:
        <input type="number" name="CLIENTE_idCLIENTE" value="<?= htmlspecialchars($visita['CLIENTE_idCLIENTE']) ?>" required>
    </label>
    <label>Data da Visita:
        <input type="date" name="data_visita" value="<?= htmlspecialchars($visita['data_visita']) ?>">
    </label>
    <label>Observações:
        <textarea name="observacoes"><?= htmlspecialchars($visita['observacoes']) ?></textarea>
    </label>

    <div class="button-group">
        <input type="submit" value="Salvar">
        <input type="button" value="Voltar" onclick="window.location.href='listar.php'">
    </div>
</form>

</body>
</html>
