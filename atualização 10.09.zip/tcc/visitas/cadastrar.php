<?php
include '../conexao.php';

$erro = '';
$sucesso = '';

if ($_POST) {
    $idVisita = (int)$_POST['idVISITA'];
    $corretorId = (int)$_POST['CORRETOR_idCORRETOR'];
    $imovelId = (int)$_POST['IMOVEL_idIMOVEL'];
    $clienteId = (int)$_POST['CLIENTE_idCLIENTE'];
    $dataVisita = $_POST['data_visita'];
    $observacoes = $_POST['observacoes'];

    $cadastrarProposta = isset($_POST['cadastrar_proposta']);

    // Verifica se já existe uma VISITA com mesmo id + cliente
    $verifica = mysqli_query($conexao, "
        SELECT * FROM VISITA 
        WHERE idVISITA = $idVisita AND CLIENTE_idCLIENTE = $clienteId
    ");

    if (mysqli_num_rows($verifica) > 0) {
        $erro = "Já existe uma visita com este ID e cliente.";
    } else {
        // Cadastra a VISITA
        $sqlVisita = "
            INSERT INTO VISITA 
            (idVISITA, CORRETOR_idCORRETOR, IMOVEL_idIMOVEL, CLIENTE_idCLIENTE, data_visita, observacoes)
            VALUES ($idVisita, $corretorId, $imovelId, $clienteId, 
                    " . ($dataVisita ? "'$dataVisita'" : "NULL") . ",
                    " . ($observacoes ? "'" . mysqli_real_escape_string($conexao, $observacoes) . "'" : "NULL") . ")
        ";

        if (mysqli_query($conexao, $sqlVisita)) {
            if ($cadastrarProposta) {
                // Se marcar para cadastrar PROPOSTA junto
                $valorProposta = (float)$_POST['valor_proposta'];
                $dataProposta = $_POST['data_proposta'];

                $sqlProposta = "
                    INSERT INTO PROPOSTA 
                    (valor, data_proposta, VISITA_idVISITA, VISITA_CLIENTE_idCLIENTE)
                    VALUES ($valorProposta, 
                            " . ($dataProposta ? "'$dataProposta'" : "NULL") . ",
                            $idVisita, $clienteId)
                ";

                if (!mysqli_query($conexao, $sqlProposta)) {
                    $erro = "Visita cadastrada, mas erro ao cadastrar proposta: " . mysqli_error($conexao);
                } else {
                    $sucesso = "Visita e proposta cadastradas com sucesso! <a href='listar.php'>Voltar</a>";
                }
            } else {
                $sucesso = "Visita cadastrada com sucesso! <a href='listar.php'>Voltar</a>";
            }
        } else {
            $erro = "Erro ao cadastrar visita: " . mysqli_error($conexao);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Visita</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 520px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="date"],
        .form-container input[type="checkbox"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #10b981;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #059669;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .sucesso {
            color: green;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php elseif ($sucesso): ?>
        <div class="sucesso"><?= $sucesso ?></div>
    <?php endif; ?>

    <label>ID Visita:
        <input type="number" name="idVISITA" min="0" required>
    </label>
    <label>ID Corretor:
        <input type="number" name="CORRETOR_idCORRETOR" min="0" required>
    </label>
    <label>ID Imóvel:
        <input type="number" name="IMOVEL_idIMOVEL" min="0" required>
    </label>
    <label>ID Cliente:
        <input type="number" name="CLIENTE_idCLIENTE" min="0" required>
    </label>
    <label>Data Visita:
        <input type="date" name="data_visita">
    </label>
    <label>Observações:
        <input type="text" name="observacoes">
    </label>

    <label>
        <input type="checkbox" name="cadastrar_proposta" onchange="toggleProposta(this)">
        Cadastrar Proposta junto
    </label>

    <div id="propostaCampos" style="display:none;">
        <label>Valor da Proposta:
            <input type="number" name="valor_proposta" min="0" step="0.01">
        </label>
        <label>Data da Proposta:
            <input type="date" name="data_proposta">
        </label>
    </div>

    <div class="button-group">
        <input type="submit" value="Cadastrar">
        <input type="button" value="Voltar" onclick="window.location.href='listar.php'">
    </div>
</form>

<script>
    function toggleProposta(checkbox) {
        document.getElementById('propostaCampos').style.display = checkbox.checked ? 'block' : 'none';
    }
</script>

</body>
</html>
