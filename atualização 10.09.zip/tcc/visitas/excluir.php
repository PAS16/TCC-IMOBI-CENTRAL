<?php
include '../conexao.php';

$erro = '';
$sucesso = '';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    
    $resultado = mysqli_query($conexao, "SELECT * FROM VISITA WHERE idVISITA = $id");
    $visita = mysqli_fetch_assoc($resultado);

    if (!$visita) {
        $erro = "Visita não encontrada.";
    } else {
        
        $verificaProposta = mysqli_query($conexao, "
            SELECT * FROM PROPOSTA 
            WHERE VISITA_idVISITA = $id 
            AND VISITA_CLIENTE_idCLIENTE = {$visita['CLIENTE_idCLIENTE']}
        ");
        $temPropostas = mysqli_num_rows($verificaProposta) > 0;
    }
}

if ($_POST) {
    $idExcluir = (int)$_POST['idVISITA'];
    $clienteId = (int)$_POST['CLIENTE_idCLIENTE'];
    $excluirPropostas = isset($_POST['excluir_propostas']) ? true : false;

    
    $verificaProposta = mysqli_query($conexao, "
        SELECT * FROM PROPOSTA 
        WHERE VISITA_idVISITA = $idExcluir 
        AND VISITA_CLIENTE_idCLIENTE = $clienteId
    ");
    $temPropostas = mysqli_num_rows($verificaProposta) > 0;

    if ($temPropostas && !$excluirPropostas) {
        $erro = "Não é possível excluir esta visita sem excluir também as propostas associadas.";
    } else {
        
        if ($excluirPropostas) {
            $sqlPropostas = "DELETE FROM PROPOSTA 
                             WHERE VISITA_idVISITA = $idExcluir 
                             AND VISITA_CLIENTE_idCLIENTE = $clienteId";
            if (!mysqli_query($conexao, $sqlPropostas)) {
                $erro = "Erro ao excluir as propostas: " . mysqli_error($conexao);
            }
        }

        if (!$erro) {
            $sql = "DELETE FROM VISITA WHERE idVISITA = '$idExcluir'";
            if (mysqli_query($conexao, $sql)) {
                $sucesso = "Visita (e propostas, se havia) excluída com sucesso! <a href='listar.php'>Voltar</a>";
            } else {
                $erro = "Erro ao excluir a visita: " . mysqli_error($conexao);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Excluir Visita</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 520px;
            text-align: left;
        }

        .form-container p {
            font-size: 16px;
            margin-bottom: 20px;
            color: #333;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1 1 auto;
            padding: 12px 0;
            font-size: 16px;
            background-color: #ef4444;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #dc2626;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .sucesso {
            color: green;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php elseif ($sucesso): ?>
        <div class="sucesso"><?= $sucesso ?></div>
    <?php elseif ($visita): ?>
        <p>Tem certeza que deseja <strong>EXCLUIR</strong> a visita de ID <strong><?= htmlspecialchars($visita['idVISITA']) ?></strong>?</p>
        <p>
            Corretor ID: <?= htmlspecialchars($visita['CORRETOR_idCORRETOR']) ?><br>
            Imóvel ID: <?= htmlspecialchars($visita['IMOVEL_idIMOVEL']) ?><br>
            Cliente ID: <?= htmlspecialchars($visita['CLIENTE_idCLIENTE']) ?><br>
            Data da Visita: <?= htmlspecialchars($visita['data_visita']) ?><br>
            Observações: <?= htmlspecialchars($visita['observacoes']) ?>
        </p>

        <?php if ($temPropostas): ?>
            <p style="color: darkred; font-weight: bold;">
                Atenção: Existem propostas vinculadas a esta visita!
            </p>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="idVISITA" value="<?= $visita['idVISITA'] ?>">
            <input type="hidden" name="CLIENTE_idCLIENTE" value="<?= $visita['CLIENTE_idCLIENTE'] ?>">

            <div class="button-group">
                <?php if ($temPropostas): ?>
                    <button type="submit" name="excluir_propostas" value="1">
                        Excluir Visita e Propostas
                    </button>
                <?php else: ?>
                    <input type="submit" value="Excluir Visita">
                <?php endif; ?>
                <input type="button" value="Cancelar" onclick="window.location.href='listar.php'">
            </div>
        </form>
    <?php endif; ?>
</div>

</body>
</html>

