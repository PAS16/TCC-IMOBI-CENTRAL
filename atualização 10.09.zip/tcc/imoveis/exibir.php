<?php
include '../conexao.php';

if (!isset($_GET['id'])) {
    echo "<p>Imóvel não especificado.</p>";
    exit;
}

$id = intval($_GET['id']);

// Busca o imóvel com o proprietário
$sql = "
    SELECT i.*, p.nome AS nome_proprietario 
    FROM IMOVEL i
    JOIN PROPRIETARIO p ON i.PROPRIETARIO_idPROPRIETARIO = p.idPROPRIETARIO
    WHERE i.idIMOVEL = $id
";
$resultado = mysqli_query($conexao, $sql);

if (mysqli_num_rows($resultado) === 0) {
    echo "<p>Imóvel não encontrado.</p>";
    exit;
}

$imovel = mysqli_fetch_assoc($resultado);

// Busca imagens do imóvel
$sql_img = "SELECT caminho FROM IMAGEM_IMOVEL WHERE IMOVEL_idIMOVEL = $id";
$res_img = mysqli_query($conexao, $sql_img);
$imagens = [];
while ($row = mysqli_fetch_assoc($res_img)) {
    $imagens[] = $row['caminho'];
}

// Se não tiver imagem no banco, usar exemplo
if (empty($imagens)) {
    $imagens = [
        "https://picsum.photos/800/400?random=1",
        "https://picsum.photos/800/400?random=2",
        "https://picsum.photos/800/400?random=3"
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8" />
<title>Detalhes do Imóvel</title>
<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: url("https://picsum.photos/1600/900?blur=10") no-repeat center center fixed;
        background-size: cover;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px;
    }

    h2 {
        color: #fff;
        text-shadow: 0 2px 6px rgba(0,0,0,0.6);
        margin-bottom: 25px;
    }

    .card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        padding: 30px;
        max-width: 900px;
        width: 100%;
    }

    .imagens {
        display: flex;
        overflow-x: auto;
        gap: 15px;
        margin-bottom: 25px;
    }

    .imagens img {
        border-radius: 12px;
        max-height: 300px;
        object-fit: cover;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }

    .info {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .info p {
        margin: 0;
        padding: 8px;
        background: #f3f4f6;
        border-radius: 8px;
        font-size: 15px;
    }

    .info strong {
        color: #2563eb;
    }

    .btn-container {
        margin-top: 30px;
        display: flex;
        justify-content: center;
        gap: 15px;
        flex-wrap: wrap;
    }

    .btn {
        background: #3b82f6;
        color: white;
        text-decoration: none;
        padding: 12px 24px;
        border-radius: 10px;
        font-weight: bold;
        transition: 0.3s;
    }

    .btn:hover {
        background: #1e40af;
    }

    @media (max-width: 700px) {
        .info {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<h2>Detalhes do Imóvel</h2>

<div class="card">
    <!-- Galeria -->
    <div class="imagens">
        <?php foreach ($imagens as $img): ?>
            <img src="<?= $img ?>" alt="Imagem do imóvel">
        <?php endforeach; ?>
    </div>

    <!-- Informações -->
    <div class="info">
        <p><strong>ID:</strong> <?= $imovel['idIMOVEL'] ?></p>
        <p><strong>Tipo:</strong> <?= htmlspecialchars($imovel['tipo']) ?></p>
        <p><strong>Endereço:</strong> <?= htmlspecialchars($imovel['endereco']) ?></p>
        <p><strong>Valor:</strong> R$ <?= number_format($imovel['valor'], 2, ',', '.') ?></p>
        <p><strong>Status:</strong> <?= htmlspecialchars($imovel['status']) ?></p>
        <p><strong>Quartos:</strong> <?= htmlspecialchars($imovel['qtd_quartos']) ?></p>
        <p><strong>Banheiros:</strong> <?= htmlspecialchars($imovel['qtd_banheiro']) ?></p>
        <p><strong>Vagas:</strong> <?= htmlspecialchars($imovel['qtd_vagas']) ?></p>
        <p style="grid-column: span 2;"><strong>Descrição:</strong> <?= htmlspecialchars($imovel['descricao']) ?></p>
        <p style="grid-column: span 2;"><strong>Proprietário:</strong> <?= htmlspecialchars($imovel['nome_proprietario']) ?></p>
    </div>
</div>

<div class="btn-container">
    <a class="btn" href="listar.php">Voltar à lista</a>
    <a class="btn" href="editar.php?id=<?= $imovel['idIMOVEL'] ?>">Editar</a>
    <a class="btn" href="excluir.php?id=<?= $imovel['idIMOVEL'] ?>">Excluir</a>
</div>

</body>
</html>
