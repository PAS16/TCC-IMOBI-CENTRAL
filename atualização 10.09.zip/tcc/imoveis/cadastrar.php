<?php
include '../conexao.php';


$proprietarios_result = mysqli_query($conexao, "SELECT idPROPRIETARIO, nome FROM PROPRIETARIO ORDER BY nome");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'];
    $endereco = $_POST['endereco'];
    $valor = floatval($_POST['valor']);
    $descricao = $_POST['descricao'];
    $status = 'Disponível';
    $qtd_quartos = intval($_POST['qtd_quartos']);
    $qtd_banheiro = intval($_POST['qtd_banheiro']);
    $qtd_vagas = intval($_POST['qtd_vagas']);
    $id_proprietario = intval($_POST['PROPRIETARIO_idPROPRIETARIO']);

    $sql = "INSERT INTO IMOVEL (PROPRIETARIO_idPROPRIETARIO, tipo, endereco, valor, descricao, status, qtd_quartos, qtd_banheiro, qtd_vagas)
            VALUES ($id_proprietario, '$tipo', '$endereco', $valor, '$descricao', '$status', $qtd_quartos, $qtd_banheiro, $qtd_vagas)";

    if (mysqli_query($conexao, $sql)) {
        echo "<p style='text-align:center; font-family:sans-serif;'>Imóvel cadastrado com sucesso! <a href='listar.php'>Voltar à lista</a></p>";
    } else {
        echo "<p style='text-align:center; font-family:sans-serif;'>Erro ao cadastrar imóvel: " . mysqli_error($conexao) . "</p>";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Imóvel</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 520px;
        }

        h2 {
            margin-top: 0;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        input[list],
        select,
        textarea {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        input:focus, select:focus, textarea:focus {
            border-color: #3b82f6;
            outline: none;
            background-color: #f0f4ff;
        }

        textarea {
            resize: vertical;
            min-height: 90px;
        }

        .btn, input[type="submit"] {
            display: inline-block;
            padding: 12px 20px;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            text-decoration: none;
            text-align: center;
        }

        .btn:hover, input[type="submit"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .btn + .btn {
            margin-left: 10px;
        }

        form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Cadastrar Novo Imóvel</h2>
    <form method="post">
        <label>Tipo:
            <input type="text" name="tipo" required>
        </label>
        <label>Endereço:
            <input type="text" name="endereco" required>
        </label>
        <label>Valor:
            <input type="number" name="valor" step="0.01" required>
        </label>
        <label>Descrição:
            <textarea name="descricao" required></textarea>
        </label>
        <label>Quartos:
            <input type="number" name="qtd_quartos" min="0" value="0" required>
        </label>
        <label>Banheiros:
            <input type="number" name="qtd_banheiro" min="0" value="0" required>
        </label>
        <label>Vagas:
            <input type="number" name="qtd_vagas" min="0" value="0" required>
        </label>
        <label>Proprietário:
            <input list="proprietarios" name="PROPRIETARIO_idPROPRIETARIO" placeholder="Digite o ID ou nome" required>
            <datalist id="proprietarios">
                <?php while ($p = mysqli_fetch_assoc($proprietarios_result)) : ?>
                    <option value="<?= $p['idPROPRIETARIO'] ?>"><?= htmlspecialchars($p['nome']) ?> (ID: <?= $p['idPROPRIETARIO'] ?>)</option>
                <?php endwhile; ?>
            </datalist>
        </label>
        <input type="submit" class="btn" value="Cadastrar Imóvel">
    </form>
    <a class="btn" href="listar.php">Voltar à lista</a>
</div>

</body>
</html>
