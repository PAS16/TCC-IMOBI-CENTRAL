<link rel="stylesheet" href="../exibir.css">
<?php
include '../conexao.php';

if (!isset($_GET['id'])) {
    echo "<p>ID do imóvel não informado.</p>";
    exit;
}

$id = intval($_GET['id']);

// Confirmação antes de excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirmar'])) {
        $delete = "DELETE FROM IMOVEL WHERE idIMOVEL = $id";
        if (mysqli_query($conexao, $delete)) {
            echo "<p>Imóvel excluído com sucesso! <a href='listar.php'>Voltar</a></p>";
        } else {
            echo "<p>Erro ao excluir: " . mysqli_error($conexao) . "</p>";
        }
    } else {
        echo "<p>Exclusão cancelada. <a href='listar.php'>Voltar</a></p>";
    }
    exit;
}
?>

<div class="container">
    <h2>Excluir Imóvel</h2>
    <p>Tem certeza de que deseja excluir este imóvel?</p>
    <form method="post">
        <input type="submit" name="confirmar" value="Sim, excluir" class="btn">
        <input type="submit" name="cancelar" value="Cancelar" class="btn">
    </form>
</div>
