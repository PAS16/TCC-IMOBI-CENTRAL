<?php
include '../conexao.php';

if (!isset($_GET['id'])) {
    echo "<p>Imóvel não especificado.</p>";
    exit;
}

$id = intval($_GET['id']); 


$sql = "
    SELECT i.*, p.nome AS nome_proprietario 
    FROM IMOVEL i
    JOIN PROPRIETARIO p ON i.PROPRIETARIO_idPROPRIETARIO = p.idPROPRIETARIO
    WHERE i.idIMOVEL = $id
";
$resultado = mysqli_query($conexao, $sql);

if (mysqli_num_rows($resultado) === 0) {
    echo "<p>Imóvel não encontrado.</p>";
    exit;
}

$imovel = mysqli_fetch_assoc($resultado);


$proprietarios_result = mysqli_query($conexao, "SELECT idPROPRIETARIO, nome FROM PROPRIETARIO ORDER BY nome");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Imóvel</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 520px;
        }

        h2 {
            margin-top: 0;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        input[type="text"], input[list], input[type="number"], select, textarea {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        input:focus, select:focus, textarea:focus {
            border-color: #3b82f6;
            outline: none;
            background-color: #f0f4ff;
        }

        textarea {
            resize: vertical;
            min-height: 90px;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<form method="post" action="salvar_edicao.php?id=<?= $imovel['idIMOVEL'] ?>" class="form-container">
    <h2>Editar Imóvel ID <?= $imovel['idIMOVEL'] ?></h2>

    <label>Tipo:
        <input type="text" name="tipo" value="<?= htmlspecialchars($imovel['tipo']) ?>" required>
    </label>

    <label>Endereço:
        <input type="text" name="endereco" value="<?= htmlspecialchars($imovel['endereco']) ?>" required>
    </label>

    <label>Valor:
        <input type="text" name="valor" value="<?= number_format($imovel['valor'], 2, ',', '.') ?>" required>
    </label>

    <label>Descrição:
        <textarea name="descricao" required><?= htmlspecialchars($imovel['descricao']) ?></textarea>
    </label>

    <label>Status:
        <select name="status" required>
            <option value="Disponível" <?= $imovel['status'] == 'Disponível' ? 'selected' : '' ?>>Disponível</option>
            <option value="Vendido" <?= $imovel['status'] == 'Vendido' ? 'selected' : '' ?>>Vendido</option>
            <option value="Alugado" <?= $imovel['status'] == 'Alugado' ? 'selected' : '' ?>>Alugado</option>
        </select>
    </label>

    <label>Quartos:
        <input type="number" name="qtd_quartos" value="<?= htmlspecialchars($imovel['qtd_quartos']) ?>" required>
    </label>

    <label>Banheiros:
        <input type="number" name="qtd_banheiro" value="<?= htmlspecialchars($imovel['qtd_banheiro']) ?>" required>
    </label>

    <label>Vagas:
        <input type="number" name="qtd_vagas" value="<?= htmlspecialchars($imovel['qtd_vagas']) ?>" required>
    </label>

    <label>Proprietário:
        <input list="proprietarios" name="PROPRIETARIO_idPROPRIETARIO" value="<?= htmlspecialchars($imovel['PROPRIETARIO_idPROPRIETARIO']) ?>" placeholder="Digite o ID ou nome" required>
        <datalist id="proprietarios">
            <?php while ($p = mysqli_fetch_assoc($proprietarios_result)) : ?>
                <option value="<?= $p['idPROPRIETARIO'] ?>"><?= htmlspecialchars($p['nome']) ?> (ID: <?= $p['idPROPRIETARIO'] ?>)</option>
            <?php endwhile; ?>
        </datalist>
    </label>

    <div class="button-group">
        <input type="submit" value="Salvar">
        <input type="button" value="Cancelar" onclick="window.location.href='listar.php'">
    </div>
</form>

</body>
</html>

