<?php
include '../conexao.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8" />
<title>Excluir Cliente</title>
<style>
    body {
        margin: 0;
        padding: 40px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(to right, #f0f4f8, #d9e2ec);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    .container {
        background: #fff;
        padding: 30px 40px;
        border-radius: 16px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        max-width: 460px;
        width: 100%;
        text-align: center;
    }
    p {
        font-size: 18px;
        color: #333;
        margin-bottom: 25px;
    }
    a, form button {
        text-decoration: none;
        display: inline-block;
        margin: 0 10px;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 16px;
        transition: background-color 0.3s ease;
        cursor: pointer;
        border: none;
    }
    .confirm {
        background-color: #ef4444;
        color: white;
    }
    .confirm:hover {
        background-color: #b91c1c;
    }
    .cancel {
        background-color: #6b7280;
        color: white;
    }
    .cancel:hover {
        background-color: #374151;
    }
    .success {
        font-size: 18px;
        color: #065f46;
        background-color: #d1fae5;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .error {
        font-size: 18px;
        color: #b91c1c;
        background-color: #fee2e2;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
</style>
</head>
<body>

<div class="container">
<?php
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    if (isset($_POST['confirm_delete'])) {
      
        mysqli_query($conexao, "DELETE FROM PROPOSTA WHERE VISITA_CLIENTE_idCLIENTE = $id");
        mysqli_query($conexao, "DELETE FROM VISITA WHERE CLIENTE_idCLIENTE = $id");
        $delete = mysqli_query($conexao, "DELETE FROM CLIENTE WHERE idCLIENTE = $id");

        if ($delete) {
            echo "<p class='success'>Cliente e visitas vinculadas excluídos com sucesso!</p>";
        } else {
            echo "<p class='error'>Erro ao excluir cliente: " . mysqli_error($conexao) . "</p>";
        }

        echo "<a href='listar.php' class='confirm'>Voltar</a>";
    } else {
        
        $tem_visitas = mysqli_query($conexao, "SELECT 1 FROM VISITA WHERE CLIENTE_idCLIENTE = $id LIMIT 1");

        if (mysqli_num_rows($tem_visitas) > 0) {
            echo "<p>Este cliente possui visitas vinculadas. Deseja excluir o cliente e todas as visitas associadas?</p>";
            echo "<form method='post'>";
            echo "<button type='submit' name='confirm_delete' class='confirm'>Sim, excluir tudo</button>";
            echo "<a href='listar.php' class='cancel'>Cancelar</a>";
            echo "</form>";
        } else {
         
            $delete = mysqli_query($conexao, "DELETE FROM CLIENTE WHERE idCLIENTE = $id");

            if ($delete) {
                echo "<p class='success'>Cliente excluído com sucesso!</p>";
            } else {
                echo "<p class='error'>Erro ao excluir cliente: " . mysqli_error($conexao) . "</p>";
            }

            echo "<a href='listar.php' class='confirm'>Voltar</a>";
        }
    }
} else {
    echo "<p class='error'>ID do cliente não informado.</p>";
    echo "<a href='listar.php' class='cancel'>Voltar</a>";
}
?>
</div>

</body>
</html>
