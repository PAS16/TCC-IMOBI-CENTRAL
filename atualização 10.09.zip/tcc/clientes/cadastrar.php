<?php
include '../conexao.php';

$mensagem = '';
$tipoMensagem = '';

$nome = $_GET['nome'] ?? '';
$cpf = $_GET['cpf'] ?? '';
$telefone = $_GET['telefone'] ?? '';
$email = $_GET['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];


    $verifica = mysqli_query($conexao, "SELECT * FROM Cliente WHERE cpf = '$cpf'");
    if (mysqli_num_rows($verifica) > 0) {
       
        header("Location: cadastrar.php?erro=cpf&nome=" . urlencode($nome) . "&cpf=" . urlencode($cpf) . "&telefone=" . urlencode($telefone) . "&email=" . urlencode($email));
        exit;
    }

 
    $sql = "INSERT INTO Cliente (nome, cpf, telefone, email) VALUES ('$nome', '$cpf', '$telefone', '$email')";
    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        $mensagem = "Cliente cadastrado com sucesso!";
        $tipoMensagem = 'sucesso';
        $nome = $cpf = $telefone = $email = ''; 
    } else {
        $mensagem = "Erro ao cadastrar cliente: " . mysqli_error($conexao);
        $tipoMensagem = 'erro';
    }
}

if (isset($_GET['erro']) && $_GET['erro'] === 'cpf') {
    $mensagem = "Erro: CPF já cadastrado!";
    $tipoMensagem = 'erro';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Cliente</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .mensagem {
            margin-bottom: 20px;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 16px;
            text-align: center;
        }

        .mensagem.sucesso {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #10b981;
        }

        .mensagem.erro {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #ef4444;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($mensagem): ?>
        <div class="mensagem <?= $tipoMensagem ?>"><?= $mensagem ?></div>
    <?php endif; ?>

    <label>Nome:
        <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>" required>
    </label>
    <label>CPF:
        <input type="text" name="cpf" value="<?= htmlspecialchars($cpf) ?>" required>
    </label>
    <label>Telefone:
        <input type="text" name="telefone" value="<?= htmlspecialchars($telefone) ?>">
    </label>
    <label>Email:
        <input type="text" name="email" value="<?= htmlspecialchars($email) ?>">
    </label>
    <div class="button-group">
        <input type="submit" value="Cadastrar">
        <input type="button" value="Voltar" onclick="history.back()">
    </div>
</form>

</body>
</html>
