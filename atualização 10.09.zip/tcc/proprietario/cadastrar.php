<?php
include '../conexao.php';

if ($_POST) {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];

    // Verifica se CPF já existe
    $cpf_esc = mysqli_real_escape_string($conexao, $cpf);
    $checkCpf = mysqli_query($conexao, "SELECT COUNT(*) AS total FROM PROPRIETARIO WHERE cpf = '$cpf_esc'");
    $row = mysqli_fetch_assoc($checkCpf);

    if ($row['total'] > 0) {
        // CPF já cadastrado
        echo '
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8" />
            <title>Erro - CPF duplicado</title>
            <style>
                body {
                    margin: 0;
                    padding: 40px 0;
                    background: linear-gradient(to right, #fef2f2, #fee2e2);
                    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                .message-box {
                    background-color: #fee2e2;
                    border: 2px solid #f87171;
                    padding: 30px 40px;
                    border-radius: 16px;
                    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
                    max-width: 420px;
                    text-align: center;
                    color: #991b1b;
                    font-size: 18px;
                }
                .message-box a {
                    display: inline-block;
                    margin-top: 20px;
                    padding: 12px 24px;
                    background-color: #f87171;
                    color: white;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 600;
                    transition: background-color 0.3s ease;
                }
                .message-box a:hover {
                    background-color: #b91c1c;
                }
            </style>
        </head>
        <body>
            <div class="message-box">
                Erro: CPF já cadastrado!<br>
                <a href="cadastrar.php">Voltar</a>
            </div>
        </body>
        </html>
        ';
        exit;
    }

    // Se CPF não existe, insere normalmente
    $nome_esc = mysqli_real_escape_string($conexao, $nome);
    $telefone_esc = mysqli_real_escape_string($conexao, $telefone);
    $email_esc = mysqli_real_escape_string($conexao, $email);

    $sql = "INSERT INTO PROPRIETARIO (nome, cpf, telefone, email)
            VALUES ('$nome_esc', '$cpf_esc', '$telefone_esc', '$email_esc')";
    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        echo '
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8" />
            <title>Sucesso</title>
            <style>
                body {
                    margin: 0;
                    padding: 40px 0;
                    background: linear-gradient(to right, #d1fae5, #bbf7d0);
                    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                .message-box {
                    background-color: #d1fae5;
                    border: 2px solid #10b981;
                    padding: 30px 40px;
                    border-radius: 16px;
                    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
                    max-width: 420px;
                    text-align: center;
                    color: #065f46;
                    font-size: 18px;
                }
                .message-box a {
                    display: inline-block;
                    margin-top: 20px;
                    padding: 12px 24px;
                    background-color: #10b981;
                    color: white;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 600;
                    transition: background-color 0.3s ease;
                }
                .message-box a:hover {
                    background-color: #047857;
                }
            </style>
        </head>
        <body>
            <div class="message-box">
                Proprietário cadastrado com sucesso!<br>
                <a href="listar.php">Voltar</a>
            </div>
        </body>
        </html>
        ';
        exit;
    } else {
        echo "Erro ao cadastrar: " . mysqli_error($conexao);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Cadastrar Proprietário</title>
    <style>
        body {
            margin: 0;
            padding: 40px 0;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            max-width: 420px;
            margin: 0 auto;
            box-sizing: border-box;
        }
        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }
        .form-container input[type="text"],
        .form-container input[type="email"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }
        .form-container input[type="text"]:focus,
        .form-container input[type="email"]:focus {
            border-color: #3b82f6;
            outline: none;
        }
        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .button-group input[type="submit"],
        .button-group a.btn {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            line-height: 1.2;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .button-group input[type="submit"]:hover,
        .button-group a.btn:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<h2>Cadastrar Proprietário</h2>
<div class="form-container">
<form method="post">
    <label>Nome: <input type="text" name="nome" required></label>
    <label>CPF: <input type="text" name="cpf" required></label>
    <label>Telefone: <input type="text" name="telefone"></label>
    <label>Email: <input type="email" name="email"></label>
    <div class="button-group">
        <input type="submit" value="Cadastrar">
        <a href="listar.php" class="btn">Voltar</a>
    </div>
</form>
</div>

</body>
</html>
