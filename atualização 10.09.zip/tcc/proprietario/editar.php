<?php
include '../conexao.php';

$erro = '';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $resultado = mysqli_query($conexao, "SELECT * FROM PROPRIETARIO WHERE idPROPRIETARIO = $id");
    $proprietario = mysqli_fetch_assoc($resultado);
}

if ($_POST) {
    $originalId = $_POST['original_id'];
    $novoId = (int)$_POST['idPROPRIETARIO'];
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];

    if ($novoId < 0) {
        $erro = "O ID não pode ser menor que 0.";
    } else {
        // Verifica se o novo ID já existe e é diferente do atual
        $verifica = mysqli_query($conexao, "
            SELECT idPROPRIETARIO 
            FROM PROPRIETARIO 
            WHERE idPROPRIETARIO = $novoId AND idPROPRIETARIO != $originalId
        ");

        if (mysqli_num_rows($verifica) > 0) {
            $erro = "O ID informado já está em uso por outro proprietário.";
        } else {
            $sql = "UPDATE PROPRIETARIO SET 
                        idPROPRIETARIO='$novoId', 
                        nome='$nome', 
                        cpf='$cpf', 
                        telefone='$telefone', 
                        email='$email' 
                    WHERE idPROPRIETARIO='$originalId'";

            if (mysqli_query($conexao, $sql)) {
                echo "Proprietário atualizado com sucesso! <a href='listar.php'>Voltar</a>";
            } else {
                $erro = "Erro ao atualizar: " . mysqli_error($conexao);
            }

            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Proprietário</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="email"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($erro): ?>
        <div class="erro"><?= $erro ?></div>
    <?php endif; ?>

    <input type="hidden" name="original_id" value="<?= $proprietario['idPROPRIETARIO'] ?>">

    <label>ID Proprietário:
        <input type="number" name="idPROPRIETARIO" value="<?= htmlspecialchars($proprietario['idPROPRIETARIO']) ?>" min="0">
    </label>
    <label>Nome:
        <input type="text" name="nome" value="<?= htmlspecialchars($proprietario['nome']) ?>" required>
    </label>
    <label>CPF:
        <input type="text" name="cpf" value="<?= htmlspecialchars($proprietario['cpf']) ?>" required>
    </label>
    <label>Telefone:
        <input type="text" name="telefone" value="<?= htmlspecialchars($proprietario['telefone']) ?>">
    </label>
    <label>Email:
        <input type="email" name="email" value="<?= htmlspecialchars($proprietario['email']) ?>">
    </label>

    <div class="button-group">
        <input type="submit" value="Salvar">
        <input type="button" value="Voltar" onclick="window.location.href='listar.php'">
    </div>
</form>

</body>
</html>