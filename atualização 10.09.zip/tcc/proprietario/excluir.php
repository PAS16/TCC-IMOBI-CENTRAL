<?php
include '../conexao.php';

if (!isset($_GET['id'])) {
    echo "ID do proprietário não especificado. <a href='listar.php'>Voltar</a>";
    exit;
}

$id = intval($_GET['id']);
$forcar = isset($_GET['forcar']) ? intval($_GET['forcar']) : 0;

// Verifica se há imóveis associados ao proprietário
$sql = "SELECT COUNT(*) AS total FROM IMOVEL WHERE PROPRIETARIO_idPROPRIETARIO = $id";
$res = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($res);
$temImoveis = $dados['total'] > 0;

if ($temImoveis && !$forcar) {
    // Aviso com opção de exclusão forçada
    echo "
    <div style='max-width: 600px; margin: 100px auto; font-family: sans-serif; text-align: center;'>
        <h3>Este proprietário possui <strong>{$dados['total']}</strong> imóvel(is) associado(s).</h3>
        <p>Você deseja:</p>
        <div style='margin-top: 20px;'>
            <a href='excluir.php?id=$id&forcar=1' style='
                background-color: #dc2626;
                color: white;
                padding: 10px 20px;
                border-radius: 6px;
                text-decoration: none;
                margin-right: 10px;
            '>Excluir proprietário <strong>e</strong> todos os imóveis</a>

            <a href='listar.php' style='
                background-color: #4b5563;
                color: white;
                padding: 10px 20px;
                border-radius: 6px;
                text-decoration: none;
            '>Cancelar</a>
        </div>
    </div>";
    exit;
}

// Realiza exclusão
if ($temImoveis && $forcar) {
    mysqli_query($conexao, "DELETE FROM IMOVEL WHERE PROPRIETARIO_idPROPRIETARIO = $id");
}

mysqli_query($conexao, "DELETE FROM PROPRIETARIO WHERE idPROPRIETARIO = $id");

echo "
<div style='max-width: 500px; margin: 100px auto; font-family: sans-serif; text-align: center; background-color: #d1fae5; padding: 30px; border-radius: 12px;'>
    <h3>Proprietário " . ($temImoveis ? "e imóveis associados" : "") . " excluídos com sucesso!</h3>
    <a href='listar.php' style='
        margin-top: 20px;
        display: inline-block;
        background-color: #10b981;
        color: white;
        padding: 10px 20px;
        border-radius: 8px;
        text-decoration: none;
    '>Voltar</a>
</div>";
?>
