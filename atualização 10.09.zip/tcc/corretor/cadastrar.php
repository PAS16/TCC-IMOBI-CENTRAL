<?php
include '../conexao.php';

$mensagem = '';
$tipoMensagem = '';

$nome = $_GET['nome'] ?? '';
$creci = $_GET['creci'] ?? '';
$telefone = $_GET['telefone'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $creci = $_POST['creci'];
    $telefone = $_POST['telefone'];

    // Verifica duplicidade de CRECI
    $verifica = mysqli_query($conexao, "SELECT * FROM CORRETOR WHERE creci = '$creci'");
    if (mysqli_num_rows($verifica) > 0) {
        header("Location: cadastrar.php?erro=creci&nome=" . urlencode($nome) . "&creci=" . urlencode($creci) . "&telefone=" . urlencode($telefone));
        exit;
    }

    // Cadastro
    $sql = "INSERT INTO CORRETOR (nome, creci, telefone) VALUES ('$nome', '$creci', '$telefone')";
    $resultado = mysqli_query($conexao, $sql);

    if ($resultado) {
        $mensagem = "Corretor cadastrado com sucesso!";
        $tipoMensagem = 'sucesso';
        $nome = $creci = $telefone = '';
    } else {
        $mensagem = "Erro ao cadastrar corretor: " . mysqli_error($conexao);
        $tipoMensagem = 'erro';
    }
}

if (isset($_GET['erro']) && $_GET['erro'] === 'creci') {
    $mensagem = "Erro: CRECI já cadastrado!";
    $tipoMensagem = 'erro';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Corretor</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(to right, #f0f4f8, #d9e2ec);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            text-align: left;
        }

        .form-container label {
            display: block;
            margin-bottom: 18px;
            font-size: 16px;
            color: #333;
        }

        .form-container input[type="text"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 6px;
            transition: border-color 0.3s;
        }

        .form-container input:focus {
            border-color: #3b82f6;
            outline: none;
        }

        .button-group {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .button-group input[type="submit"],
        .button-group input[type="button"] {
            flex: 1;
            padding: 12px 0;
            font-size: 16px;
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 0 5px;
        }

        .button-group input[type="submit"]:hover,
        .button-group input[type="button"]:hover {
            background-color: #2563eb;
            transform: translateY(-2px);
        }

        .mensagem {
            margin-bottom: 20px;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 16px;
            text-align: center;
        }

        .mensagem.sucesso {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #10b981;
        }

        .mensagem.erro {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #ef4444;
        }
    </style>
</head>
<body>

<form method="post" class="form-container">
    <?php if ($mensagem): ?>
        <div class="mensagem <?= $tipoMensagem ?>"><?= $mensagem ?></div>
    <?php endif; ?>

    <label>Nome:
        <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>" required>
    </label>
    <label>CRECI:
        <input type="text" name="creci" value="<?= htmlspecialchars($creci) ?>" required>
    </label>
    <label>Telefone:
        <input type="text" name="telefone" value="<?= htmlspecialchars($telefone) ?>">
    </label>

    <div class="button-group">
        <input type="submit" value="Cadastrar">
        <input type="button" value="Voltar" onclick="history.back()">
    </div>
</form>

</body>
</html>
